import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-withousidebar',
  templateUrl: './withousidebar.component.html',
  styleUrls: ['./withousidebar.component.css']
})
export class WithousidebarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
