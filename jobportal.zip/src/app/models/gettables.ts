export class gettable{
    userId:number;
    id:number;
    title:string;
    completed:boolean;
}