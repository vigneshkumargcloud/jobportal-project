export class forgotPass{
    id:number;
    password:string;

}