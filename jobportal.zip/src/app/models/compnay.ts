export class company{
    id:number;
    company_name:string="";
    profile_desc:string;
    business_sid:any;
    establishment_date:string;
    company_website:string;
    companyimage:File;

 }