export class jobType{
    jobtype:string="";
    id:number;
 }