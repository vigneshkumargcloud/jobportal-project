export class businesStream{
    business_stream_name:string="";
    id:number;
   
 }