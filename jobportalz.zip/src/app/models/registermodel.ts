export class register{
   //   id:number;
    user_type_id:number;
    email:string;
    password:string;
    date_of_birth:string;
    gender:string="male";
    isactive:number=1;
    contactNumber:number;
    userimage:string="sdadad";
    reg_date:string;
    username:string="";
    companyname:string="";
 }