export class forgot{
    email:string;

}