export class jobs{
    companyName:string;
    joblocation:string;
    is_active:string;
   
}
export class jobsList{
    companyName:string;
    joblocation:string;
    salary:string;
    jobdes:string;
    img:string;
}