export class replies{
    msgid:number;
    seekerreply:string;
    employeerreply:string;
   
 }