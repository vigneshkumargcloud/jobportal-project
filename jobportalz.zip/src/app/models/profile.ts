export class CandidateProfile{
    username:string="";
    email:String="";
    contactNumber:String="";
    Website:String="";
    JobDescription:String="";
    Address:String="";
   skills:string="";
   SelectSkills:string='';
   user_account_id:number;
    // Country:String="";
    // State:String="";
    city:string="";
    // FullAddress:String="";
    // Latitude:Number=0;
    // Longitude:Number=0;
    // zoom:Number=0;
 
    
 }