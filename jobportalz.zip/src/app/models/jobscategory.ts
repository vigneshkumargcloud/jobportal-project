export class JobCategory{
    jobcate:string="";
    id:number;
 }