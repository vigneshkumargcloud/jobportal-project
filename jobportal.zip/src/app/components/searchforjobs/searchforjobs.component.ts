import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-searchforjobs',
  templateUrl: './searchforjobs.component.html',
  styleUrls: ['./searchforjobs.component.css']
})
export class SearchforjobsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
