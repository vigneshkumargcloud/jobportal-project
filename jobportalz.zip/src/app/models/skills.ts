export class skills{
    user_account_id:number;
    skillname:string;
   
 }