export class jobpost{
    posted_by:number;
    jobtype_id:number=1;
    description:string;
    minsalary:number;
    maxsalary:number;
    salary_type_id:number=1;
    jobcategory_id:number;
    jobtitle:string;
    workinghours:number;
    state:string;
    city:string;
    pin:number;
    sarting_date:Date;
    end_date:Date;
    userid:number;
    
    created_date:Date;

 }