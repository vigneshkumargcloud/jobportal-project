export class message{
    message:string="";
    userid:number;
    companyid:number;
    uid:any;
    username:string;
   
 }