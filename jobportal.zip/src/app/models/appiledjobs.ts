export class appliedjobs{
    user_acc_id:number;
    job_post_id:number;
    uid:number;
    jobappliedfor:number;
    js:string;
    applstatus:number;
   
 }