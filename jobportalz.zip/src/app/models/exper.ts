export class expere{
    user_account_id:number;
    Companyname:string;
    designation:string;
    yearsworked:number;
    current_salary:number;
   
 }