export class favmodel{
    jobid:number;
    userid:number;
   
 }