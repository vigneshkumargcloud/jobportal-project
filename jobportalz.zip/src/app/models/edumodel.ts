export class edumodel{
    user_account_id:number;
    instutename:string;
    degreename:string;
    percentage:number;
   
 }