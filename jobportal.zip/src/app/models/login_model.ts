export class login{
   username:string='';
   password:string='';
   user_type_id:number=3;
   token:string;
}
export class Employeer{
   companyname:string='';
   password:string='';
   user_type_id:number=2;
   token:string;
}
export class admin{
   username:string='';
   password:string='';
   user_type_id:number=3;
   token:string;
}