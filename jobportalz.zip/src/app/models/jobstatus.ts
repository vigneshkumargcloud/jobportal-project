export class jobstatus{
    jobstatusname:string="";
    // id:number;
   
 }